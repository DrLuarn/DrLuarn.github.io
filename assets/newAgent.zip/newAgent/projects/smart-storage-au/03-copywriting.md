# 行銷文案：智慧儲能管理系統（暫定品牌名稱：GridMind AI）

> *中文註記：策略文件中未提供正式產品/品牌名稱，本文案暫以「**GridMind AI**」作為工作名稱（呼應「AI 調度大腦」定位），待 CEO/品牌團隊確認正式命名後全文替換即可，不影響文案結構與訴求邏輯。*
>
> *文案主語言為英文（澳洲市場），關鍵段落附中文註解說明訴求邏輯與對應策略文件依據。*

---

## Slogan

**"Any Battery. One Smart Brain. More Money Back."**

> *中文註解：三段式結構對應三大核心賣點——「Any Battery」= 跨品牌相容（不綁定單一硬體）；「One Smart Brain」= AI 調度大腦定位（軟體智慧層，非硬體商）；「More Money Back」= 從「被動儲電」升級為「主動賺錢」（動態電價套利＋VPP 分潤）。避免空泛口號，每個詞都對應策略文件中明確的差異化賣點。*

備用（強調 B2B 合作夥伴場景）：
**"The AI Layer Every Battery Brand Is Missing."**

---

## 網站文案

### Hero

**Eyebrow:** AI Energy Management, Built for Australia

**H1:** Any Battery. One Smart Brain. More Money in Your Pocket.

**Sub-headline:**
GridMind AI upgrades the battery you already own — no matter the brand — with AI-powered charging, live wholesale price trading, and Virtual Power Plant (VPP) participation. No new hardware. No brand lock-in. Just a smarter way to use the battery you've already paid for.

**Primary CTA button:** Check If Your Battery Qualifies
**Secondary CTA button:** I'm a Retailer or Installer →

> *中文註解：Hero 副標刻意不用「顛覆」「革命」等空泛詞，改用「你已經買的電池」「不用換硬體」「不綁品牌」三個具體事實，直接對應策略文件第 1、3 節的差異化定位（純軟體、跨品牌），並埋入雙客群分流入口（家庭用戶 vs 合作夥伴）。*

---

### 核心賣點（Value Propositions）

**1. Works With Any Battery You Already Own**
Tesla, Sigenergy, Sungrow, SolarEdge, Redback and more — GridMind AI sits on top of your existing system. You don't need to replace hardware to get smarter energy management.

**2. Your Battery Starts Working *For* You**
Most batteries only do basic self-consumption. GridMind AI automatically charges and discharges based on live wholesale electricity prices, so your battery buys low and sells/uses high — every single day, without you lifting a finger.

**3. Get Paid to Support the Grid**
Enrol your battery in Virtual Power Plant (VPP) events through our platform and earn credits or payments for the capacity you're not using — turning idle storage into an extra income stream.

**4. One App, Full Visibility — No Matter the Brand**
See your savings, VPP earnings, and battery health in a single real-time dashboard, even if your battery, inverter, and solar panels are all different brands.

> *中文註解：四個賣點對應策略文件「主動賺錢」核心敘事與 GTM Phase 1 訴求（動態電價套利、VPP 分潤、跨品牌 App），刻意用「你已經擁有的電池」降低轉換門檻，呼應存量市場（35萬套已安裝電池）的切入邏輯。*

---

### 產品特色說明（Feature Highlights）

- **Cross-Brand Compatibility** — One AI dispatch layer across major battery and inverter brands sold in Australia; you're never locked into a single ecosystem.
- **AI-Optimised Charge/Discharge** — Real-time optimisation engine reacts to wholesale spot-market price signals and your household usage pattern, automatically.
- **VPP Enrolment & Revenue Sharing** — Seamless opt-in to Virtual Power Plant events, with transparent earnings tracking — no separate app or hardware required.
- **Real-Time Monitoring Dashboard** — Track daily savings, VPP event history, and battery health at a glance, on web or mobile.
- **Grid-Compliant by Design** — Dispatch logic built to AS/NZS 4777.1:2024 / 4777.2:2020 frequency and voltage response standards, so every automated action is safe and grid-compliant.

> *中文註解：合規重點（AS/NZS 4777.1/4777.2）特別列出，是策略文件 GTM Phase 1 強調的信任建立要素，對零售商/安裝商合作夥伴尤其重要，也向消費者傳遞「自動化很安全」的訊息。*

---

### 目標客群分眾說明

**面對家庭用戶（Homeowners）—— 親近、易懂、強調具體省錢／賺錢感受**

> Already have solar and a battery? Your battery is probably doing less than it could. GridMind AI plugs into your existing setup in minutes, starts trading on live electricity prices automatically, and lets you opt into VPP events for extra income — all from one simple app. No electrician visit, no new hardware, cancel anytime.

**面對電力零售商 / 安裝商合作夥伴（Retailers & Installers）—— 專業、理性、強調商業效益與整合門檻**

> GridMind AI is a white-label DER orchestration layer you can embed directly into your existing app or service. For retailers, it means a ready-to-deploy VPP dispatch engine across your customers' mixed-brand battery fleet — without building AI optimisation in-house. For installers, it means offering a smarter, brand-agnostic value-add that increases customer retention and differentiates you from hardware-only competitors — without becoming an energy retailer yourself.

> *中文註解：兩段語氣刻意區隔——消費者端強調「簡單、免安裝、隨時取消」降低嘗試門檻；B2B 端強調「白牌授權」「不需自建 AI」「不需申請零售牌照」，直接對應策略文件第 2、4 節的 B2B2C 商業模式與風險規避邏輯（不申請 AEMO Aggregator 牌照）。*

---

### CTA

**家庭用戶（Homeowners）**
- 主要 CTA：**"See How Much You Could Save — Free Compatibility Check"**（按鈕文字：*Check My Battery*）
- 次要 CTA：**"Join the Waitlist for NSW Early Access"**

**合作夥伴（Retailers & Installers）**
- 主要 CTA：**"Let's Build Your VPP Platform Together"**（按鈕文字：*Talk to Our Partnerships Team*）
- 次要 CTA：**"Download the Partner Integration Overview"**

> *中文註解：家庭用戶 CTA 用「免費檢測相容性」降低承諾門檻（symmetric with Phase 1 免費試用/低價入門策略）；合作夥伴 CTA 用「一起打造」建立平等合作語氣，而非單向銷售語氣，呼應 B2B2C 模式中「我們是技術供應商，不是競爭者」的定位。*

---

## 簡報稿重點（業務／合作夥伴簡報用，5 頁大綱）

**Slide 1 — The Problem**
- Australia has 350,000+ newly installed home batteries in the last 10 months alone — but most are only doing basic self-consumption.
- Battery hardware brands are locked in a price war; consumers are confused by fragmented, brand-siloed apps.
- Retailers need to orchestrate DER fleets across multiple battery brands for VPP programs — but building that AI layer in-house is slow and expensive.

**Slide 2 — The Solution**
- GridMind AI is the AI dispatch brain that sits on top of any battery brand — we don't sell hardware, we make the hardware smarter.
- Delivered two ways: a consumer subscription app for existing battery owners, and a white-label SaaS layer for retailers and installers.
- No new hardware, no brand lock-in, no AEMO Aggregator licence required to get started.

**Slide 3 — How It Works**
- Real-time AI optimisation engine trades on wholesale/spot electricity prices, automatically charging and discharging for maximum value.
- Seamless VPP enrolment lets battery owners earn credits or payments during grid events.
- One dashboard gives full visibility — savings, VPP earnings, battery health — regardless of hardware brand.
- All dispatch logic is built to AS/NZS 4777.1:2024 / 4777.2:2020 for safe, compliant automation.

**Slide 4 — Why GridMind AI**
- vs. Hardware brands (Tesla, Sigenergy, SolarEdge, Redback): we don't compete on battery cost — we make *every* battery smarter, including theirs.
- vs. Sonnen: we lead with measurable economic outcomes (spot-price arbitrage, VPP earnings), not brand storytelling.
- vs. SwitchDin: we focus specifically on retailer white-label SaaS and consumer subscription upsell — a clearer, faster path to revenue for partners, not a generic HEMS platform.

**Slide 5 — The Opportunity & Next Steps**
- Phase 1 focus: NSW, targeting the installed base of existing battery owners via independent installer partnerships.
- Revenue model for partners: SaaS licensing + VPP revenue share — no exclusivity required, no competing hardware sold.
- Ask: pilot integration with your app/customer base, starting with a defined NSW cohort — results and savings/earnings data available to support your VPP strategy.

> *中文註解：五頁大綱嚴格依「問題 → 解法 → 差異化 → 效益 → 行動呼籲」邏輯排列，每頁只放可驗證、對齊策略文件的事實（存量市場數字、合規標準、商業模式），未捏造具體節費百分比或案例數據，待 Phase 1 試點有實際成效後再補充「Proof/Case Study」頁。*
