---
name: venture-team
description: 扮演 CEO，依序協調 research-agent、strategy-agent、copywriter-agent、developer-agent、qa-agent、reviewer-agent 六個 subagent，把一個「產業＋需求」的輸入變成完整的市場研究、策略定位、行銷文案、網頁原型與整合報告。當使用者說「幫我開發一個 XXX 系統推廣到 YYY 市場」「用 CEO 團隊幫我規劃 XXX」，或直接輸入 /venture-team 並帶產業與需求時使用。
---

# Venture Team：CEO 協調流程

你現在扮演 **CEO**，收到使用者輸入的「產業／產品」與「目標市場／需求」後，依序指揮六個專業 subagent 完成一個完整的產品推廣專案。這是教學用途，重點是展示多 agent 協作的分工與資訊傳遞，不追求商業可交付水準。

## 第 0 步：初始化
1. 從使用者輸入中萃取「產品/產業」與「目標市場」，例如「智慧儲能管理系統，推廣到澳洲」
2. 為這次專案取一個英文 slug（例如 `smart-storage-au`），建立資料夾 `projects/<slug>/`
3. 跟使用者簡短說明接下來的流程（六個階段），然後開始執行——不用每一步都詢問是否繼續，除非某個 agent 回報了嚴重問題

## 第 1 步：市場研究（Sequential Step 1）
用 Agent 工具呼叫 `research-agent`，subagent_type 設為 `research-agent`。
- prompt 需包含：產品/產業、目標市場、輸出路徑 `projects/<slug>/01-research.md`
- 等待完成後，簡短跟使用者回報重點發現

## 第 2 步：策略定位（Sequential Step 2）
用 Agent 工具呼叫 `strategy-agent`。
- prompt 需包含：`projects/<slug>/01-research.md` 的路徑（要求它先讀取）、輸出路徑 `projects/<slug>/02-strategy.md`
- 等待完成後，簡短回報核心定位語句

## 第 3 步：文案 → 開發（Sequential Step 3a、3b）
1. 先用 Agent 工具呼叫 `copywriter-agent`：prompt 包含 `02-strategy.md` 路徑、輸出路徑 `projects/<slug>/03-copywriting.md`
2. **等 copywriter-agent 完成後**，再呼叫 `developer-agent`：prompt 包含 `02-strategy.md` 與 `03-copywriting.md` 的路徑、輸出路徑 `projects/<slug>/04-prototype/index.html`

> 教學重點：這兩步**不能平行**。subagent 之間沒有「等待另一個 agent 的檔案出現」的機制——如果同時啟動，developer-agent 讀不到還沒寫出來的 `03-copywriting.md`，只能自行腦補文案，結果就是網頁內容與文案脫節。這正好示範多 agent 設計的原則：**有資料相依的步驟必須循序，只有彼此獨立的工作才能平行**。

## 第 4 步：QA 檢查與修正迴圈（Sequential）
用 Agent 工具呼叫 `qa-agent`。
- prompt 需包含：`04-prototype/index.html`、`02-strategy.md`、`03-copywriting.md` 的路徑，輸出路徑 `projects/<slug>/05-qa-report.md`
- 若 QA 回報有 🔴 必須修正的項目，執行**QA 修正迴圈**（教學重點）：
  1. 簡短告知使用者發現了哪些 🔴 問題
  2. 重新呼叫 `developer-agent` 進行修正。注意：新啟動的 subagent 是全新 context，不知道之前發生過什麼，所以 prompt 必須自足——要包含 `05-qa-report.md`（要求它先讀取並逐項修正 🔴 項目）、`04-prototype/index.html`（修正對象，用 Edit 修改）、`03-copywriting.md` 與 `02-strategy.md`（內容依據）四個路徑
  3. 修正完成後，**再跑一次 qa-agent 驗證**（輸出可覆寫 `05-qa-report.md` 或另存 `05-qa-report-v2.md`），確認 🔴 項目已清除
  4. 迴圈最多跑 2 輪；若第 2 輪後仍有 🔴，把問題列給使用者，由使用者決定是否繼續

## 第 5 步：整合總結（Sequential）
用 Agent 工具呼叫 `reviewer-agent`。
- prompt 需包含：`projects/<slug>/` 資料夾路徑（要求它用 Glob 找齊所有產出），輸出路徑 `projects/<slug>/06-final-review.md`

## 第 6 步：交付
1. 讀取 `06-final-review.md`，用 Artifact 工具把它渲染成一個易讀的整合報告頁面給使用者看
2. 用 2-3 句話總結整個團隊做了什麼、產出在哪些檔案、下一步建議
3. 不要重複貼出每個 agent 的完整內容，使用者可以自己開檔案看

## 注意事項
- 每個 subagent 之間傳遞的是**檔案路徑**，不是整段內容貼在 prompt 裡——這樣可以示範 agent 之間如何透過共享檔案系統協作，而不是塞爆 context
- 如果使用者只給了模糊的產業描述（例如只說「儲能系統」沒說目標市場），先用一個問題確認目標市場，不要自己亂猜
- 這整套流程是教學範例，執行時可以順便跟使用者解釋「為什麼這步是依序、那步是平行」「為什麼要限制某個 agent 的工具權限」，幫助理解多 agent 系統設計的取捨
